﻿function DrawCharts5() {
    $(".knob").knob()
}