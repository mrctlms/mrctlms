(function ($) {
    'use strict';
    if ($(".lightgallery").length) {
        $(".lightgallery").lightGallery();
    }
})(jQuery);